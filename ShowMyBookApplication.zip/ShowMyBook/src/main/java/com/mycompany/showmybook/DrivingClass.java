
package com.mycompany.showmybook;

import com.google.zxing.WriterException;
import java.io.IOException;




public class DrivingClass {

public static void main (String [] args) throws IOException, WriterException{
  

  BookMyShow user = new BookMyShow();
 
  if(user.invokeLoginClass()){
 
 String language =  user.showAvailableLanguagesForTheShows();
   System.out.println("Selected Movie, "+user.showTheMovieBasedOnLanguage(language));
  
  user.setLocation();
  user.showClosestTheaterWithShowTimings();
  if(user.bookTheTicket()){
    if(user.initiatePaymentGateway()){
        
         user.generateTransactionID();
         user.displayOrderSummary();
         user.generateTicketSummary();
         user.generateQRForTicket();
         user.displayQRCode();
         user.ratingAndFeedback();
       if(user.userWantsCancellation()){
          user.selectedLanguage = null;
          user.selectedTheater = null;
          user.selectedMovie = null;
          user.selectedTiming = null;
          user.location = null;
          user.confirmationStatus = false;
          System.out.println(user.firstname +", your Ticket has Been cancelled for the Transaction ID: "+ user.transID);
        }    
        else{
          System.out.println("Thank you! for using our System to book your favourite Show");
        }
     } 
  }
  if(user.logoutPrompt()){
    
    System.out.println("Successfully Logged Out! Thank you!!");
    
    System.out.println("Login: "+ user.loginStatus);
    
  }
 
 
  
  
// void callPayment() 
  
  
  
}

}

}