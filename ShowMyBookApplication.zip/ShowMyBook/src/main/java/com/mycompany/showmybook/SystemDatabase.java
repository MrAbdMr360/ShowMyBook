/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.showmybook;
import java.security.SecureRandom;
public class SystemDatabase {

static int silverPrice = 150;
static int goldPrice = 220;
static int platinum = 350;

static int classPrices[] = {150, 220, 350};
static final String SOURCE = "0123456789QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm";

private static final String seatAlphaAloc = "ABCDEFGH";
private static final String seatNumAloc = "123456789";



static SecureRandom secureRnd = new SecureRandom();

static String phoneNumber[]={"9886954726", "8123586458","8123468864", "9449204403", "6364304546"};

static String classesInTheater[] = {"Silver", "Gold", "Platinum"};


static String[] newUser = new String[50];
static  String[] firstname = {"Shri", "Srinivasa", "prajwal", "rowdy","Varuna"};
 static String[] lastname = {"Hari", "R", "Srinath","bro", "Kumara"};
 static  String Username[] = {"meshrihari19@gmail.com", "srinivasamngr@gmail.com","meprajwal@gmail.com", "rachuu1629@gmail.com","askmevarun@gmail.com"};
 static String Password []= {"12345", "12345", "12345","your password", "12345"};
 
 
 
static  String KannadaMovies[] = {"Dia", "Love Mocktail", "Arjun", "Rajkumara", "Chakravarthy"};





 static String TeluguMovies[] = {"DJ","Alavo Vaikuntapuramlo", "Venky maama", "Bheesma", "Sarileru nikkevvaru"};
 
 
 
 static String[] AshokaTheater = {"Dia", "DJ"};
 
 
 
 static String[] BharathiTheater= {KannadaMovies[1], TeluguMovies[1]};
 
 
 
static String ShowTimings[] = {"10:30", "2:30", "6:30", "9:30"};



static String TamilMovies[] = {"Irumbu Manithan", "Mafia: Chapter 1", "Jasmine", "Pulikodi Devan", "Maayanadhi", "Darbar", "En Sangathu Aala Adichavan Evanad"};


static String HindiMovies[] = {"Angrezi Medium", "Guilty", "Baaghi", "Thappad", "Shubh Mangal Zyada Saavdhan", "Malang"};
static String EnglishMovies[] = {"Black Widow", "Mulan", "No Time To Die", "Top Gun: Maverick", "Tenet", "Harley Quinn: Birds of prey"};



static String MalayalamMovies[] = {};
 
 static String languages[] = {"Kannada", "Telugu","Tamil", "Hindi", "English"};
 static String theaters[] = {"Ashoka Theater", "Bharathi Theater", "Shantala Theater", "Gayathri"};
static String [] ShanthalaTheater = {KannadaMovies[1],KannadaMovies[1], KannadaMovies[0], KannadaMovies[0]};
 
 
 static String[] GayathryTheater = {TeluguMovies[1], TeluguMovies[1], TeluguMovies[0], TeluguMovies[1]};
 
 
 
 static String TheatersMovie[] = {"AshokaTheater", "BharathiTheater", "ShanthalaTheater", "GayathryTheater"};








 

 
 public static String randomString() {
 int length = 15;
  StringBuilder sb = new StringBuilder(length);  
    for (int i = 0; i < length; i++){ 
    sb.append(SOURCE.charAt(secureRnd.nextInt(SOURCE.length())));
     }
 return sb.toString(); }

 



 public static String seatRow() {
 int length = 1;
  StringBuilder sb = new StringBuilder(length);  
    for (int i = 0; i < length; i++){ 
    sb.append(seatAlphaAloc.charAt(secureRnd.nextInt(seatAlphaAloc.length())));
     }
 return sb.toString(); }
 
 public static String seatNumber() {
 int length = 1;
  StringBuilder sb = new StringBuilder(length);  
    for (int i = 0; i < length; i++){ 
    sb.append(seatNumAloc.charAt(secureRnd.nextInt(seatAlphaAloc.length())));
     }
 return sb.toString(); }

 
}