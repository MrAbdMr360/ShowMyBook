package drivingclass;
import java.util.*;

public class flight2 extends flight1  {

protected int businessClassStart = 1;
protected int businessClassEnd = 10;

protected int ecoClassEnd = 30;
protected int maxBusinessSeatInRow = 4;


protected int busBaggageLimit = 25;
protected int maxBusBaggageLimit = 30;

protected int ecoClassStart = 11;






flight2(String selectedClass){   
       super(selectedClass);
    }
flight2(String Date, String boarding, String destination, int numberOfPassengers, String selectedClass){
      
   super(Date, boarding, destination, numberOfPassengers, selectedClass);
   
}

void showBusinessClassLayout(){

System.out.println("***BUSINESS CLASS SEATING LAYOUT****");
System.out.println("A\t\t\tB\t\t\t\t\tC\t\t\tD");
  int noSeats = 0;
  for(i = businessClassStart ; i <= businessClassEnd ; i++){
    
    for(j = 0 ; j < maxBusinessSeatInRow ; j++){
       noSeats++;
         if(noSeats < 10){
           System.out.printf(noSeats + "\t\t\t");
        }
        else{
           System.out.printf(noSeats + "\t\t");
        }
        if(j == 1 ){
          System.out.printf("\t\t");
        }
      
      
    }
    System.out.println("");
    
  } 
  System.out.println("*************"); 
}

  String generatePNRForF2(){

       if("economy".equalsIgnoreCase(super.selectedClass)){
         
         super.PNR = "f2"+super.generatePNR();
//     System.out.println(super.PNR);
         return super.PNR;
       }
 else if("business".equalsIgnoreCase(super.selectedClass)){
     super.PNR = "f2"+super.generatePNR();
  //   System.out.println(super.PNR);
     return super.PNR;
}
else{
  
  System.out.println("Invalid Class for the Flight");
  return "";
  
}

}
   

  boolean makePayment(int R){
 Scanner scanf = new Scanner(System.in);
  System.out.println("Amount "+ R+" Rs Has been been Generated");
  System.out.println("Enter 1 to make payment");
  
  int confirmation = scanf.nextInt();
  if(confirmation == 1){
    return true;
  }
  else{
    return false;
  }
  
  
  
  
  
}
 
  @Override
  
   void getBaggageLimit(String PNR){
    if(PNR == this.PNR){
      
      
      switch(PNR.charAt(2)){
        case 'E':  System.out.println("The Maximum Baggage Limit: "+  maxEcoBaggageLimit);
        System.out.println("Allowed Baggage limit : "+ecoBaggageLimit); 
      break;
      case 'B': System.out.println("The Maximum Baggage Limit:"+ maxBusBaggageLimit);
      System.out.println("Allowed Baggage limit : "+busBaggageLimit); break;
      default : System.out.println("Invalid PNR ");
      }
     
    }else{
      System.out.println("Invalid PNR number");
    }
  
  }
  
  
  
}