package drivingclass;
import java.util.*;
public class flight3 extends flight2{


protected int maxFirstBaggageLimit = 40;
protected int firstBaggageLimit = 30;
protected int maxFirstRow = 10;
protected int maxRowSeatsInFirst= 2;
flight3(String selectedClass){   
       super(selectedClass);
    }
flight3(String Date, String boarding, String destination, int numberOfPassengers, String selectedClass){
      
   super(Date, boarding, destination, numberOfPassengers, selectedClass);
   
}

   void showFirstClassLayout(){
   System.out.printf("A\t\t\t\t\tB%n");
   System.out.println("***First Class Seats Layout***");
int   noSeats = 0;
      for(i = 0; i < maxFirstRow ; i++){
        for(j= 0;j < maxRowSeatsInFirst; j++){
        noSeats++;
        if(noSeats < 10){
          System.out.printf(noSeats + "\t\t\t\t\t");
        }
          else if(noSeats>= 10 && noSeats <= 99){
          System.out.printf(noSeats + "\t\t\t\t");
          
          
          
        }
      }
    System.out.println(""); 
   }
System.out.println("********");
}

String generatePNRForf3(){


if("economy".equalsIgnoreCase(super.selectedClass)){
         
         super.PNR = "f3"+super.generatePNR();
 //     System.out.println(super.PNR);
         return super.PNR;
       }
 else if("business".equalsIgnoreCase(super.selectedClass)){
     super.PNR = "f3"+super.generatePNR();
  //   System.out.println(super.PNR);
     return super.PNR;
}
else{
  if("first".equalsIgnoreCase(super.selectedClass)){
     super.PNR = "f3"+super.generatePNR();
  //   System.out.println(super.PNR);
     return super.PNR;
}
else{
  return "";
}
  
}
 
}


void buyExcessBaggageForF3(int k){
  if(super.PNR.charAt(2) == 'E' || super.PNR.charAt(2) == 'e'){
    super.buyExcessBaggage(k);
  }
  else{
    if(super.PNR.charAt(2) == 'B' || super.PNR.charAt(2) == 'b'){
      this.buyExcessBaggage(k);
    }
    else{
      if(super.PNR.charAt(2) == 'f' || super.PNR.charAt(2) == 'F'){
      this.buyExcessBaggage(k);
    }
    else{
      System.out.println("Invalid PNR NUMBER! ");
    }
    }
  }
}
 

   
   

  boolean makePayment(int R){
 Scanner scanf = new Scanner(System.in);
  System.out.println("Amount "+ R+" Rs Has been been Generated");
  System.out.println("Enter 1 to make payment");
  
  int confirmation = scanf.nextInt();
  if(confirmation == 1){
    return true;
  }
  else{
    return false;
  }
  
  
  
  
  
}
 
  
    @Override
  
   void getBaggageLimit(String PNR){
    if(PNR == this.PNR){
      
      
      switch(PNR.charAt(2)){
        case 'E':  System.out.println("The Maximum Baggage Limit: "+  maxEcoBaggageLimit);
        System.out.println("Allowed Baggage limit : "+ecoBaggageLimit); 
      break;
      case 'B': System.out.println("The Maximum Baggage Limit:"+ maxBusBaggageLimit);
      System.out.println("Allowed Baggage limit : "+busBaggageLimit); break;
      case 'F': System.out.println("The Maximum Baggage Limit:"+ maxFirstBaggageLimit);
      System.out.println("Allowed Baggage limit : "+firstBaggageLimit); break;
      default : System.out.println("Invalid PNR ");
      }
     
    }else{
      System.out.println("Invalid PNR number");
    }
  
  }
  




}