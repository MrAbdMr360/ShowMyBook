package drivingclass;
import java.util.*;

public class flight {
protected String Date;
 protected String boarding;
 protected String destination;
 protected String selectedClass;
 protected int numberOfPassengers;
  int i;
  int j;
 protected int maxFirstBaggageLimit = 40;
protected int firstBaggageLimit = 30;

protected int busBaggageLimit = 25;
protected int maxBusBaggageLimit = 30;

protected int maxEcoSeatsInRow = 6;
protected int totalRowsInEco = 5;
protected int ecoBaggageLimit = 15;
protected int maxEcoBaggageLimit = 20;
protected int ecoPerKG = 2000;
protected int busPerKG = 3000;
protected int firstPerKG = 4000;
protected int currentBaggageWeight = 0;
protected String[] selectedSeats = new String[50];
protected String[] passengerNames = new String[50];
protected int ecoClassStart = 1;
protected int ecoClassEnd = 30;
protected String PNR;


void buyExcessBaggage(int k){


if(this.selectedClass.equalsIgnoreCase("economy")){
  
 Scanner scanf = new Scanner(System.in) ;
  if((k+ecoBaggageLimit)>ecoBaggageLimit && (k + ecoBaggageLimit) <= maxEcoBaggageLimit){
  
  System.out.printf("Would You Like to Buy Excess Baggage Allowance%n Each KG of the Excess baggage in Class: %s cost %d Rs%n1. Continue %n2. Return%nEnter Your Choice: ",this.selectedClass, ecoPerKG);
      int choice = scanf.nextInt();
      if(choice == 1){
      int  totalAmount = (k)*ecoPerKG;
        if(this.makePayment(totalAmount)){
          this.currentBaggageWeight = k;
          System.out.println("Hurray! Your Baggage Limit has been Raised by "+ this.currentBaggageWeight+" KG");
        }
        else{
          System.out.println("Payment Unsuccessful");
        }
      }
      
  
}

else {

System.out.println("Sorry! The Baggage Limit May Have Exceeded or Below the Threshold Baggage Weight Limit!!");


}


}else{
 
 
 if(this.selectedClass.equalsIgnoreCase("business")){
   

Scanner scanf = new Scanner(System.in) ;
  if((k+busBaggageLimit)>busBaggageLimit && (k + busBaggageLimit) <= maxBusBaggageLimit){
  
  System.out.printf("Would You Like to Buy Excess Baggage Allowance%n Each KG of the Excess baggage Class: %s cost %d Rs%n1. Continue %n2. Return%nEnter Your Choice: ",this.selectedClass, busPerKG);
      int choice = scanf.nextInt();
      if(choice == 1){
      int  totalAmount = (k)*busPerKG;
        if(this.makePayment(totalAmount)){
          this.currentBaggageWeight = k;
          System.out.println("Hurray! Your Baggage Limit has been Raised by "+ this.currentBaggageWeight+" KG");
        }
        else{
          System.out.println("Payment Unsuccessful");
        }
      }
      
  
}
else {

System.out.println("Sorry! The Baggage Limit May Have Exceeded or Below the Threshold Baggage Weight Limit!!");


}


 }else{
   
   if(this.selectedClass.equalsIgnoreCase("first")){
     
     
     Scanner scanf = new Scanner(System.in) ;
  if(((k+firstBaggageLimit)>firstBaggageLimit) && ((k + firstBaggageLimit) <= maxFirstBaggageLimit)){
  
  System.out.printf("Would You Like to Buy Excess Baggage Allowance%n Each KG of the Excess baggage Class: %s cost %d Rs%n1. Continue %n2. Return%nEnter Your Choice: ",this.selectedClass, firstPerKG);
      int choice = scanf.nextInt();
      if(choice == 1){
      int  totalAmount = (k)*firstPerKG;
        if(this.makePayment(totalAmount)){
          this.currentBaggageWeight = k;
          System.out.println("Hurray! Your Baggage Limit has been Raised by "+ this.currentBaggageWeight+" KG");
        }
        else{
          System.out.println("Payment Unsuccessful");
        }
      }
      
  
}

     
     
   }
   
   
  else {

System.out.println("Sorry! The Baggage Limit May Have Exceeded or Below the Threshold Baggage Weight Limit!!");
   
   
 }
 
 
 
 
 
 


}

 
 
 
 
 
}
 
}

boolean makePayment(int R){
 Scanner scanf = new Scanner (System.in);
  System.out.println("Amount "+ R+" Rs Has been been Generated");
  System.out.println("Enter 1 to make payment");
  
  int confirmation = scanf.nextInt();
  if(confirmation == 1){
    return true;
  }
  else{
    return false;
  }
  
}


 
 
 
 void getBaggageLimit(String PNR){
    if(PNR == this.PNR){
      
      
      switch(PNR.charAt(2)){
        case 'E':  System.out.println("The Maximum Baggage Limit: "+  maxEcoBaggageLimit);
        System.out.println("Allowed Baggage limit : "+ecoBaggageLimit); 
      break;
      default : System.out.println("Invalid PNR ");
      }
     
    }else{
      System.out.println("Invalid PNR number");
    }
 }
 Boolean cancel(String PNR){
   System.out.printf("Are you Sure, %nyou want you to Cancel the Ticket%n1. Cancel The ticket%n2. Exit%nEnter the Choice: ");
   Scanner scanf = new Scanner (System.in);
   int choice = scanf.nextInt();
   if(choice == 1){
   System.out.println("Ticket has been Cancelled");
     return true;
     
   }
   else{
   System.out.println("Ticket is Not Cancelled");
     return false;
   }
   }
 




}
