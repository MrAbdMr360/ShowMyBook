package drivingclass;
import java.lang.*;
import java.util.*;
import drivingclass.flight1;
import drivingclass.flight2;

public class drivingClass {



 public static void main(String[] args) {
  Scanner scanf = new Scanner(System.in);
   String date;
   String boardingPlace;
   String destinationPlace;
   String selectedClass;
   int numberOfPassengers;
   
   System.out.println("Enter Your Journey Date(DD/MM/YYYY): ");
   date = scanf.next();
   System.out.println("Enter Your Boarding Place");
   boardingPlace = scanf.next();
   System.out.println("Enter Your Destination Place");
   destinationPlace = scanf.next();
   System.out.println("Type in your desired Class (Economy, Business, or First)");
   selectedClass = scanf.next();
  System.out.println("Enter total Number of Passengers");  
  numberOfPassengers = scanf.nextInt();
    
   System.out.println("Please Select Your Desired AirLine");
   System.out.println("1. Aircraft 1 - Available Class: Economy");
   System.out.println("2. Aircraft 2 - Available Class: Economy, Business");
   System.out.println("3. Aircraft 3 - Available Class: Economy, Business, First");
   System.out.print("Enter your Choice here: ");
   int choice = scanf.nextInt();
    
    
   switch(choice) {
     
    case 1: invokeClassFlight1(date, boardingPlace, destinationPlace, numberOfPassengers, selectedClass); break;
    case 2:  invokeClassFlight2(date, boardingPlace, destinationPlace, numberOfPassengers, selectedClass); break;
    case 3: invokeClassFlight3(date, boardingPlace, destinationPlace, numberOfPassengers, selectedClass); break;
   default : System.out.println("Invalid Choice. Please Try Again!");  
   }
    
    
}

static public void invokeClassFlight1(String date, String boardingPlace, String destinationPlace, int numberOfPassengers, String selectedClass){
  Scanner scanf = new Scanner(System.in);
  
  flight1 flight = new flight1(selectedClass);
 flight1 passenger = new flight1(date, boardingPlace, destinationPlace, numberOfPassengers, selectedClass);
  
  passenger.showAvailableSeats();
  passenger.reservation(selectedClass);
  passenger.generatePNRforF1();
  System.out.println("Please Enter The Extra Baggage Weight ");
  int extraWeight = scanf.nextInt();
  passenger.buyExcessBaggage(extraWeight);
System.out.println("Would You Like you Know the Allowed Baggage Limit for the PNR");
System.out.println("1. Show The Baggage Limit");
System.out.println("2. Ignore");
int choice = scanf.nextInt();
if(choice == 1){ passenger.getBaggageLimit(passenger.generatePNRforF1());
 }
System.out.println("***CANCELLATION**");
System.out.println("1. Cancel");
System.out.println("2. Don't Cancel");
choice = scanf.nextInt();
if(choice == 1){ boolean cancel = passenger.cancel(passenger.generatePNRforF1());

if(cancel){
  passenger = null;
}





}try{
 System.out.println("*Printing Your Air Ticket***"); passenger.printDetailsOfTrip(passenger.generatePNRforF1());
  passenger.printPNR();
  
}
catch(NullPointerException e){
  System.out.println("Sorry Cannot Print Cancelled Ticket!");
}
}
static public void invokeClassFlight2(String date, String boardingPlace, String destinationPlace, int numberOfPassengers, String selectedClass){
  Scanner scanf = new Scanner(System.in);
  flight2 flight = new flight2(selectedClass);
 flight2 passenger = new flight2(date, boardingPlace, destinationPlace, numberOfPassengers, selectedClass);
  passenger.showBusinessClassLayout();
  passenger.showAvailableSeats();
  
  passenger.reservation(selectedClass);
  passenger.generatePNRForF2();
  System.out.println("Please Enter The Extra Baggage Weight ");
  int extraWeight = scanf.nextInt();
  passenger.buyExcessBaggage(extraWeight);
System.out.println("Would You Like you Know the Allowed Baggage Limit for the PNR");
System.out.printf("1. Show The Baggage Limit%n2. Ignore%n");
int choice = scanf.nextInt();
if(choice == 1){ passenger.getBaggageLimit(passenger.generatePNRForF2());
 }
System.out.println("***CANCELLATION**");
System.out.println("1. Cancel");
System.out.println("2. Don't Cancel");
choice = scanf.nextInt();
if(choice == 1){ boolean cancel = passenger.cancel(passenger.generatePNRForF2());

if(cancel){
  passenger = null;
}





}try{
 System.out.println("*Printing Your Air Ticket***"); passenger.printDetailsOfTrip(passenger.generatePNRForF2());
  passenger.printPNR();
  
}
catch(NullPointerException e){
  System.out.println("Sorry Cannot Print Cancelled Ticket!");
}
}




static public void invokeClassFlight3(String date, String boardingPlace, String destinationPlace, int numberOfPassengers, String selectedClass){

Scanner scanf = new Scanner(System.in);
  flight3 flight = new flight3(selectedClass);
 flight3 passenger = new flight3(date, boardingPlace, destinationPlace, numberOfPassengers, selectedClass);
 passenger.showFirstClassLayout();
  passenger.showBusinessClassLayout();
  passenger.showAvailableSeats();
  
  passenger.reservation(selectedClass);
  passenger.generatePNRForf3();
  System.out.println("Please Enter The Extra Baggage Weight ");
  int extraWeight = scanf.nextInt();
  passenger.buyExcessBaggage(extraWeight);
System.out.println("Would You Like you Know the Allowed Baggage Limit for the PNR");
System.out.printf("1. Show The Baggage Limit%n2. Ignore%n");
int choice = scanf.nextInt();
if(choice == 1){ passenger.getBaggageLimit(passenger.generatePNRForf3());
 }
System.out.println("***CANCELLATION**");
System.out.println("1. Cancel");
System.out.println("2. Don't Cancel");
choice = scanf.nextInt();
if(choice == 1){ boolean cancel = passenger.cancel(passenger.generatePNRForf3());

if(cancel){
  passenger = null;
}





}try{
 System.out.println("*Printing Your Air Ticket***"); passenger.printDetailsOfTrip(passenger.generatePNRForf3());
  //passenger.printPNR();
  
}
catch(NullPointerException e){
  System.out.println("Sorry Cannot Print Cancelled Ticket!");
}



  
  
}







}