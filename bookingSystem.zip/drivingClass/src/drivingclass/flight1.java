package drivingclass;
import java.util.Scanner;


public class flight1 extends flight {
 
 
flight1(String selectedClass){   
      this.selectedClass = selectedClass;
    }
flight1(String Date, String boarding, String destination, int numberOfPassengers, String selectedClass){
      
     this.Date = Date;
     this.boarding = boarding;
     this.destination = destination;
     this.numberOfPassengers = numberOfPassengers;    
     this.selectedClass = selectedClass;
}
  
  
void  showAvailableSeats() {
    int noSeats = 0;
   System.out.println("*****ECONOMY CLASS SEATING LAYOUT****"); System.out.println("A\t\t\t\t\tB\t\t\t\t\t\t\tC\t\t\t\t\tD\t\t\t\t\t\t\tE\t\t\t\t\tF");
    for(i = ecoClassStart;i <= ecoClassEnd ; i++){
      for(j = 0;j < maxEcoSeatsInRow ; j++){
      noSeats++;
        if(noSeats < 10){
          System.out.printf(noSeats + "\t\t\t\t\t");
        }
        else if(noSeats>= 10 && noSeats <= 99){
          System.out.printf(noSeats + "\t\t\t\t");
        }
        else{
          System.out.printf(noSeats + "\t\t\t");
        }
        if(j == 1 || j == 3){
          System.out.printf("\t\t");
        }
        
      }
      System.out.println("");
      
    }
    System.out.println("***************");
    
  }   

   void reservation(String className){
   
   
   
   Scanner scanf = new Scanner(System.in);
     System.out.println("From The Above Layout please select Desired Seats");
     System.out.printf("Enter the Seat Numbers in Your Selected Class - %s: %n", className );
 for(i = 0; i < this.numberOfPassengers ; i++){
 System.out.printf(i+1+". ");
   this.selectedSeats[i] = scanf.next();
       
 }
 System.out.println("Enter The passenger Name: ");
 for(i = 0; i< this.numberOfPassengers ;i++){
   
   System.out.printf(i+1+". ");
 this.passengerNames[i] = scanf.next();
   
   
 }
     
   }

 String generatePNR(){
  
String PNR = this.selectedClass.charAt(0)+"-"+ database.randomString(6);
 
 return PNR;
}

String generatePNRforF1(){
  
  this.PNR = "f1"+this.selectedClass.charAt(0)+"-"+ database.randomString(6);
  return this.PNR;
}
 

 
 
 void printDetailsOfTrip(String PNR){
   
   
   if(PNR.equals(this.PNR)){
     System.out.println("PNR: "+this.PNR);
     System.out.println("Boarding: "+this.boarding);
     System.out.println("Destination: "+this.destination);
     System.out.println("Class: "+this.selectedClass);
     System.out.println("Journey Date: "+this.Date);
     System.out.printf("Booked Seats\t\tPassenger Name%n");
    // System.out.print("Booked Seats: ");
     for(i = 0; i < this.numberOfPassengers ; i++){
       System.out.printf(this.selectedSeats[i] +"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"+super.passengerNames[i]);
     System.out.println(""); 
     }
     
   }
   else{
     System.out.println("Invalid PNR number");
   }
 }
void printPNR()
{
  // System.out.println("Your PNR : "+ this.PNR);
}

}